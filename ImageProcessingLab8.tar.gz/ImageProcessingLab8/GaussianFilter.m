clear;
Image = imread('cameraman.tif');
%figure , imshow(Image);
sizeImage = size(Image);
m = sizeImage(1);
cm = m/2;
n = sizeImage(2);
cn = n/2;
paddedSize = 2.*sizeImage;
for i=1:2*m
    for j=1:2*n
        if(i>=m||j>=n)
            ImagePadded(i,j) = 0;
        else 
            ImagePadded(i,j) = Image(i,j);
        end
    end
end
c = -1;
for i=1:m
    for j=1:n
        ImagePadded(i,j) = ImagePadded(i,j)*(c.^(i+j-2));
    end
end
%figure , imshow(ImagePadded);
checkfft = fft2(ImagePadded);

r1 = m;
r2 = n;
radius = 30 ;
power = 2;
ImageDouble = im2double(Image);
stdDeviation = std(ImageDouble);
stdDeviation = std(stdDeviation);
for i=1:2*m
    for j=1:2*n
        distance = (((i-r1).^2)+((j-r2).^2)).^0.5;
        distance = distance.^2;
        
        ImageChange(i,j) = 2.71828.^(distance/(2*100.^2));
        
    end
end
figure , imshow(ImageChange);

DftLowPassFilter = checkfft.*ImageChange;
%for i=1:2*m
 %   for j=1:2*n
  %      DftLowPassFilter(i,j) = checkfft(i,j)*ImageLowPass(i,j);
   % end
%end
%figure , imshow(DftLowPassFilter);

ImageInverseFFT = real(ifft2(DftLowPassFilter));
%ImageInverseFFT = uint8(ImageInverseFFT);
%ImageInverseFFT = mat2gray(ImageInverseFFT);
for i=1:m
    for j=1:n
        ImageInverseFFTMul(i,j) = ImageInverseFFT(i,j)*(c.^(i+j-2));
    end
end

figure , subplot(2,1,1) , imshow(Image);
title('ButterWorth with D = 30 n=2');
ImageInverseFFTMulMat2Gray = mat2gray(ImageInverseFFTMul);
subplot(2,1,2), imshow(ImageInverseFFTMulMat2Gray);



