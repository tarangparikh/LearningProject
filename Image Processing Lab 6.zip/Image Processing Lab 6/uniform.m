clear;
matrix = zeros(1,256);
a = 50;
b = 90;
for i=1:256
    if(i>=a&&i<=b)
        matrix(i) = 1/(b-a);
    else 
        matrix(i) = 0;
    end
end


mapMatrix = randi(b,a,255);
Image = imread('C:\Users\user1\Desktop\demo.tif');
size = size(Image);

figure , subplot(2,2,1) , imshow(Image);
subplot(2,2,2) ,imhist(Image);


probablity = .1;

for i=1:size(1)
    Random = floor(randi([1,255],(size(1)*probablity),1));
    
    
    for j=1:size(1)*probablity
            if(Image(i,j)<a||Image(i,j)>b)
            Image(i,Random(j)) = Image(i,Random(j)) + randi([a,b],1);
            
               
            end
        
    end
end


subplot(2,2,3) ,  imshow(Image);
subplot(2,2,4) , imhist(Image);



