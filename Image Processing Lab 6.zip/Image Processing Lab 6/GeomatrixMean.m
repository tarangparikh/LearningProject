clear;
Image = imread('C:\Users\user1\Desktop\uni.tif');
figure , imshow(Image);
matrixSize = 3;
matrix = ones(matrixSize);
factor = matrixSize*matrixSize;
size = size(Image);

lower = floor(matrixSize/2);




for i=1:size(1)+matrixSize-1
    for j=1:size(2)+matrixSize-1
        if((i<=lower||i>(size(1)+lower))||(j<=lower||j>(size(2)+lower)))
            ImagePadded(i,j)=0;
        else
            ImagePadded(i,j)=Image(i-lower,j-lower);
        end
    end
end



sizeImagePadded = size + 2*lower;

for i=(lower+1):sizeImagePadded(1)-lower
    for j=(lower+1):sizeImagePadded(2)-lower
        HoldMatrix = ImagePadded(((i-lower):((i-lower)+matrixSize-1)),((j-lower):((j-lower)+matrixSize-1)));
        HoldMatrix = geomean(HoldMatrix);
        HoldMatrix = geomean(HoldMatrix);
      
        ImageFinal(i-lower,j-lower) = HoldMatrix;
    
    
    end
end

ImageFinal = uint8(ImageFinal);
figure, subimage(1,2,1) , imshow(ImageFinal)


