Image = imread('cameraman.tif');
Intensity = 0.2;
figure ,subplot(3,2,1) , imshow(Image)
subplot(3,2,2) ,imhist(Image);
DupImage = imnoise(Image,'gaussian',Intensity);
subplot(3,2,3) , imshow(DupImage);
subplot(3,2,4) ,imhist(DupImage);
Intensity = 0.8;
DupImage = imnoise(Image,'gaussian',Intensity);
subplot(3,2,5) , imshow(DupImage);
subplot(3,2,6) ,imhist(DupImage);