clear;
Image = imread('/home/user1/Desktop/GaussianBoard.tif');

figure ,subplot(1,2,1), imshow(Image);
title('Guassian Noise');

matrixSize = 3;
matrix = ones(matrixSize);
factor = matrixSize*matrixSize;
size = size(Image);

lower = floor(matrixSize/2);




for i=1:size(1)+matrixSize-1
    for j=1:size(2)+matrixSize-1
        if((i<=lower||i>(size(1)+lower))||(j<=lower||j>(size(2)+lower)))
            ImagePadded(i,j)=0;
        else
            ImagePadded(i,j)=Image(i-lower,j-lower);
        end
    end
end



sizeImagePadded = size + 2*lower;

for i=(lower+1):sizeImagePadded(1)-lower
    for j=(lower+1):sizeImagePadded(2)-lower
        HoldMatrix = ImagePadded(((i-lower):((i-lower)+matrixSize-1)),((j-lower):((j-lower)+matrixSize-1)));
        HoldMatrix = harmmean(HoldMatrix);
        HoldMatrix = harmmean(HoldMatrix);
      
        ImageFinal(i-lower,j-lower) = HoldMatrix;
    
    
    end
end

ImageFinal = uint8(ImageFinal);
subplot(1,2,2) , imshow(ImageFinal);
title('Harmonic Mean Filter');


