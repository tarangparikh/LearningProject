clear;
Image = imread('cameraman.tif');


size = size(Image);

pdf = zeros(1,256);
cdf = zeros(1,256);

for i=1:size(1)
    for j=1:size(2)
    
        pdf(1,Image(i,j)+1)=pdf(1,Image(i,j)+1)+1;
    
    end
end

figure , subplot(2,1,1), imhist(Image)
subplot(2,1,2) , bar(pdf)

