clear;
Image = imread('cameraman.tif');

imhist(Image);
size = size(Image);

pdf = zeros(1,256);
cdf = zeros(1,256);

for i=1:size(1)
    for j=1:size(2)
    
        pdf(1,Image(i,j)+1)=pdf(1,Image(i,j)+1)+1;
    
    end
end

pdf = pdf/(size(1)*size(2));
plot(pdf)

cdf(1,1)=pdf(1,1);
for i=2:256
    cdf(1,i) = cdf(1,i-1)+pdf(1,i);
end
plot(cdf)

cdf = cdf * 255;

plot(cdf)

DemoImage = zeros(size(1),size(2));

for i=1:size(1)
    for j=1:size(2)
    
        DemoImage(i,j) = cdf(1,Image(i,j)+1);
        
    end
end

DemoImage = uint8(DemoImage);
figure , subplot(2,1,1) , imshow(Image)
subplot(2,1,2) , imhist(Image)
figure , subplot(2,1,1) , imshow(DemoImage)
subplot(2,1,2) , imhist(DemoImage)





