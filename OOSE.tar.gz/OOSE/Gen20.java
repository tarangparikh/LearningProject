
import java.util.*;

public class Gen20
{
	static <T extends Comparable<T>, V extends T> boolean isIn(T t, V[] vArr)
	{
		for(T i : vArr)
		{
			if (i.equals(t))
				return true;			
		}
		return false;
	}
	public static void main(String[] args) 
	{
		Integer a[] = { 97, 12, 23, 54, 83, 42, 93, 13};		
		
		if (isIn(20, a))
			System.out.println(20 + " belongs to array " + Arrays.toString(a));
		else		
			System.out.println(20 + " doesn't belong to array " +  Arrays.toString(a));
			
			System.out.println(42 + " belongs to array " +  Arrays.toString(a));
		else		
			System.out.println(42 + " doesn't belong to array "  + Arrays.toString(a));
	}
}
