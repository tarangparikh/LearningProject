#include<stdio.h>
#include<time.h>
#include<pthread.h>
#include<unistd.h>
void recursiveCall(int n){
		if(n>0){
		recursiveCall(n-1);
		recursiveCall(n-1);
		}
}

int main(){
        int root = getpid();
		
		int child = fork();
		int id = getpid();
        
        int parent = getppid();
        printf("Process id = %d Parent Id = %d \n",getpid(),getppid());


		time_t timec,times;
		timec = time(NULL);

		recursiveCall(29);

		times = time(NULL);
		if(root==id){
		printf("Id of the child = %d \n",child);
		printf("Total time of execution = %ld seconds \n",times-timec);
		}
		return 0;

}
